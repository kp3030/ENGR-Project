
#include "Servo.h"
#include "TextLCD.h"
#include "Keypad.h"
#include "hcsr04.h"
#include "mbed.h"
#include "Rfid.h"
#include "Buzzer.h"

// Pin setups
TextLCD lcd(p10, p12, p15, p16, p29, p30); // RS, EN, D4, D5, D6, D7
HCSR04 usensor(p5, p6);
Rfid rfid(p13, p14);
// Assuming Buzzer is a custom class; adjust if it’s DigitalOut


Serial device(p9, p10); // Bluetooth HC-05
Serial pc(USBTC, USBRX); // Debugging
DigitalOut led1(p22);   // Green LED (access granted)
DigitalOut led2(p28);   // Red LED (access denied)

// Servo setup
Servo myservo;

// Keypad setup (front door)
const byte ROWS = 4;
const byte COLS = 4;
char keys[ROWS][COLS] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'*', '0', '#', 'D'}
};
byte rowPins[ROWS] = {2, 3, 4, 5};
byte colPins[COLS] = {14, 15, 16, 17};
Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);

const char correctPassword[] = "1234";
char enteredPassword[5];
int digitCount = 0;

const int LOCKED_POS = 0;
const int UNLOCKED_POS = 90;

void setup() {
  pc.begin(9600);
  device.begin(9600); // Initialize Bluetooth
  myservo.attach(6);
  lcd.begin(16, 2);
  lcd.setCursor(0, 0);
  lcd.print("Enter Password:");
  myservo.write(LOCKED_POS);
  memset(enteredPassword, 0, sizeof(enteredPassword));
  led1 = 0; // LEDs off initially
  led2 = 0;
}

void openingbackdoor() {
  unsigned int dist = usensor.get_dist_cm();
  pc.printf("Distance = %ld cm\r\n", dist);

  if (dist == 200) { // Trigger at 200 cm (adjust threshold as needed)
    int id = rfid.read();
    pc.printf("Tag ID = %d\n\r", id);
    if (id) 
    { 
      led1 = 1; // Green LED on
      lcd.clear();
      lcd.print("Courier Access");
      myservo.write(UNLOCKED_POS); // Open backdoor
      pc.printf("Backdoor opened for courier\n\r");

      char button = '0'; // '0' = not pressed, '1' = pressed
      while (button != '1') {
        if (device.readable()) {
          button = device.getc();
          pc.printf("Button state = %c\n\r", button);
        }
      }
      myservo.write(LOCKED_POS); // Close backdoor
      led1 = 0;
      lcd.clear();
      lcd.print("Backdoor Locked");
      pc.printf("Backdoor closed\n\r");
      wait_ms(1000);
    } else { // Invalid RFID
      notopeningdoor();
    }
  }
}

void notopeningdoor() {
  led2 = 1; // Red LED on
  lcd.clear();
  lcd.print("RFID Denied");
  wait_ms(2000);
  led2 = 0;
  pc.printf("Attempt to rescan RFID\n\r");
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Enter Password:");
}

void loop() {
  // Front door: Keypad handling
  char key = keypad.getKey();
  if (key != NO_KEY) {
    lcd.setCursor(0, 1);

    switch (key) {
      case '0': case '1': case '2': case '3': case '4':
      case '5': case '6': case '7': case '8': case '9':
        if (digitCount < 4) {
          enteredPassword[digitCount] = key;
          digitCount++;
          lcd.print(key);
        }
        if (digitCount == 4) {
          if (strcmp(enteredPassword, correctPassword) == 0) {
            lcd.clear();
            lcd.print("Access Granted");
            myservo.write(UNLOCKED_POS);
            led1 = 1;
            wait_ms(3000);
            myservo.write(LOCKED_POS);
            led1 = 0;
            lcd.clear();
            lcd.print("Front Locked");
            wait_ms(1000);
          } else {
            lcd.clear();
            lcd.print("Access Denied");
            led2 = 1;
           
            wait_ms(1000);
            led2 = 0;
            mybuz.off();
          }
          digitCount = 0;
          memset(enteredPassword, 0, sizeof(enteredPassword));
          lcd.clear();
          lcd.setCursor(0, 0);
          lcd.print("Enter Password:");
        }
        break;

      case '*':
        digitCount = 0;
        memset(enteredPassword, 0, sizeof(enteredPassword));
        lcd.clear();
        lcd.print("Reseting....");
        wait_ms(1000);
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("Enter Password:");
        break;

      case 'A': case 'B': case 'C': case 'D': case '#':
        lcd.clear();
        lcd.print("Invalid Key");
        wait_ms(1000);
        lcd.clear();
        lcd.setCursor(0, 0);
        lcd.print("Enter Password:");
        break;

      default:
        break;
    }
    wait_ms(200); // Debounce
  }

  // Backdoor: RFID and ultrasonic handling
  usensor.start();
  wait_ms(100); // Short delay to allow measurement
  openingbackdoor();
}
